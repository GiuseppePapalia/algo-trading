package com.giuseppepapalia.algotrading.ibkr.constants;

public enum InterpolationMethod {

	LINEAR, CUBIC;

}
