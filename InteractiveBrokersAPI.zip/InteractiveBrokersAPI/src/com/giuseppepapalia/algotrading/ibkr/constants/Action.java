package com.giuseppepapalia.algotrading.ibkr.constants;

public enum Action {

	BUY, SELL;
	
}
