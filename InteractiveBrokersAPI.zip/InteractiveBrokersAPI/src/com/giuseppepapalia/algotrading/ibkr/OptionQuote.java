package com.giuseppepapalia.algotrading.ibkr;

public class OptionQuote extends Quote {

}
